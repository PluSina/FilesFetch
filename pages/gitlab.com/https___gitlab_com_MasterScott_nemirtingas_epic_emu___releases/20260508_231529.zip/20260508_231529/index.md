# Visited: https://gitlab.com/MasterScott/nemirtingas_epic_emu/-/releases
**Time:** Fri May  8 23:15:39 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (0 files)
_No media files downloaded_

## Other Links
- [/-/manifest.json](/-/manifest.json)
- [/MasterScott/nemirtingas_epic_emu/-/releases.atom](/MasterScott/nemirtingas_epic_emu/-/releases.atom)
- [/assets/application-e6c60c961f10ab15508399367f590217b1f5349bfb6b484910ac73293bc52bf9.css](/assets/application-e6c60c961f10ab15508399367f590217b1f5349bfb6b484910ac73293bc52bf9.css)
- [/assets/application_dark-2597fa8cee8def09ea222bc7f5c8ac9f415816ca45c7447e70fe05852c6c7c39.css](/assets/application_dark-2597fa8cee8def09ea222bc7f5c8ac9f415816ca45c7447e70fe05852c6c7c39.css)
- [/assets/fonts-deb7ad1d55ca77c0172d8538d53442af63604ff490c74acc2859db295c125bdb.css](/assets/fonts-deb7ad1d55ca77c0172d8538d53442af63604ff490c74acc2859db295c125bdb.css)
- [/assets/gitlab-mono/GitLabMono-29c2152dac8739499dd0fe5cd37a486ebcc7d4798c9b6d3aeab65b3172375b05.woff2](/assets/gitlab-mono/GitLabMono-29c2152dac8739499dd0fe5cd37a486ebcc7d4798c9b6d3aeab65b3172375b05.woff2)
- [/assets/gitlab-mono/GitLabMono-Italic-af36701a2188df32a9dcea12e0424c380019698d4f76da9ad8ea2fd59432cf83.woff2](/assets/gitlab-mono/GitLabMono-Italic-af36701a2188df32a9dcea12e0424c380019698d4f76da9ad8ea2fd59432cf83.woff2)
- [/assets/gitlab-sans/GitLabSans-9892dc17af892e03de41625c0ee325117a3b8ee4ba6005f3a3eac68510030aed.woff2](/assets/gitlab-sans/GitLabSans-9892dc17af892e03de41625c0ee325117a3b8ee4ba6005f3a3eac68510030aed.woff2)
- [/assets/gitlab-sans/GitLabSans-Italic-f96f17332d67b21ada2dfba5f0c0e1d5801eab99330472057bf18edd93d4ccf7.woff2](/assets/gitlab-sans/GitLabSans-Italic-f96f17332d67b21ada2dfba5f0c0e1d5801eab99330472057bf18edd93d4ccf7.woff2)
- [/assets/highlight/themes/dark-b2fa723200af7b5f3b9e4478161d984ce37ab1c4f4fac8407e8e12fec2d8e5f0.css](/assets/highlight/themes/dark-b2fa723200af7b5f3b9e4478161d984ce37ab1c4f4fac8407e8e12fec2d8e5f0.css)
- [/assets/highlight/themes/white-3e4f99f7678bc281e0acfacb2313bca0361fec21d357958f670d3b992ab562fd.css](/assets/highlight/themes/white-3e4f99f7678bc281e0acfacb2313bca0361fec21d357958f670d3b992ab562fd.css)
- [/assets/page_bundles/commit_description-9e7efe20f0cef17d0606edabfad0418e9eb224aaeaa2dae32c817060fa60abcc.css](/assets/page_bundles/commit_description-9e7efe20f0cef17d0606edabfad0418e9eb224aaeaa2dae32c817060fa60abcc.css)
- [/assets/page_bundles/notes_shared-a194998fc7c1d41bb05ecc92ee92d62f8348ddedf142d7292f5ff1d29f5dabe5.css](/assets/page_bundles/notes_shared-a194998fc7c1d41bb05ecc92ee92d62f8348ddedf142d7292f5ff1d29f5dabe5.css)
- [/assets/page_bundles/releases-0904075beabf23cae3406d11e36843d469225419b387c1a94e929d913e1a1d24.css](/assets/page_bundles/releases-0904075beabf23cae3406d11e36843d469225419b387c1a94e929d913e1a1d24.css)
- [/assets/page_bundles/work_items-4eb3a0c0fb49f836cb3ac1f262bb38b9c7e98f7c38bd0e96f4b917de3f5da4c5.css](/assets/page_bundles/work_items-4eb3a0c0fb49f836cb3ac1f262bb38b9c7e98f7c38bd0e96f4b917de3f5da4c5.css)
- [/assets/tailwind_cqs-18f8b686eabaedbdeb4a2d1c58106e585f7437c8a399dea6ff71bc003731740f.css](/assets/tailwind_cqs-18f8b686eabaedbdeb4a2d1c58106e585f7437c8a399dea6ff71bc003731740f.css)
- [/assets/webpack/6d04052d.d4408540.chunk.js](/assets/webpack/6d04052d.d4408540.chunk.js)
- [/assets/webpack/commons-pages.groups-pages.groups.achievements-pages.groups.activity-pages.groups.analytics.ci_cd_an-70bf1f75.ce5cad53.chunk.js](/assets/webpack/commons-pages.groups-pages.groups.achievements-pages.groups.activity-pages.groups.analytics.ci_cd_an-70bf1f75.ce5cad53.chunk.js)
- [/assets/webpack/commons-pages.projects.edit-pages.projects.releases.index-pages.projects.releases.show.4832775b.chunk.js](/assets/webpack/commons-pages.projects.edit-pages.projects.releases.index-pages.projects.releases.show.4832775b.chunk.js)
- [/assets/webpack/commons-pages.projects.releases.edit-pages.projects.releases.index-pages.projects.releases.new-pages-ee9f51e7.ecb5add0.chunk.js](/assets/webpack/commons-pages.projects.releases.edit-pages.projects.releases.index-pages.projects.releases.new-pages-ee9f51e7.ecb5add0.chunk.js)
- [/assets/webpack/commons-pages.projects.releases.index-pages.projects.releases.show.f89df75a.chunk.js](/assets/webpack/commons-pages.projects.releases.index-pages.projects.releases.show.f89df75a.chunk.js)
- [/assets/webpack/main.3381c340.chunk.js](/assets/webpack/main.3381c340.chunk.js)
- [/assets/webpack/pages.projects.releases.index.54837f30.chunk.js](/assets/webpack/pages.projects.releases.index.54837f30.chunk.js)
- [/assets/webpack/runtime.55a7f14e.bundle.js](/assets/webpack/runtime.55a7f14e.bundle.js)
- [/assets/webpack/sentry.03d16221.chunk.js](/assets/webpack/sentry.03d16221.chunk.js)
- [/assets/webpack/super_sidebar.23467250.chunk.js](/assets/webpack/super_sidebar.23467250.chunk.js)
- [/assets/webpack/tracker.1eb446cb.chunk.js](/assets/webpack/tracker.1eb446cb.chunk.js)
- [/search/opensearch.xml](/search/opensearch.xml)
- [https://snowplowprd.trx.gitlab.net](https://snowplowprd.trx.gitlab.net)

## Stats
- Links: 31
- Media: 0
